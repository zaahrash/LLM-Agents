#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import rclpy
from rclpy.node import Node
from std_msgs.msg import String
import openai  # Assuming you have the OpenAI library for LLM interaction

class ManagerAgent(Node):
    def __init__(self):
        super().__init__("manager_agent")

        # System prompt for LLM explaining the role of the manager agent
        self.system_prompt = """
        You are a Manager Agent responsible for coordinating multiple agents to disassemble a structure. 
        Your tasks involve monitoring each agent (Stability, Planning, Expert Knowledge, and Human-Robot Communicator) 
        and detecting errors in their execution. When an error occurs, you need to find a solution or provide a warning 
        if a solution is not available. You will interact with the following agents:

        1. Stability Agent: Evaluates the stability of structures.
        2. Planning Agent: Plans the disassembly steps.
        3. Expert Knowledge Agent: Provides expert-level knowledge about the disassembly.
        4. Human-Robot Communicator: Manages communication between human and robot.
        """

        # Subscriptions for the status updates from the agents
        self.stability_sub = self.create_subscription(String, "/stability_status", self.stability_callback, 10)
        self.planning_sub = self.create_subscription(String, "/planning_status", self.planning_callback, 10)
        self.expert_sub = self.create_subscription(String, "/expert_status", self.expert_callback, 10)
        self.human_robot_sub = self.create_subscription(String, "/human_robot_status", self.human_robot_callback, 10)

        # Publisher to send commands to agents
        self.command_pub = self.create_publisher(String, "/agent_commands", 10)

        # Start by publishing the first task to the Stability Agent
        self.publish_command("Start stability analysis")

    # Function to interact with the LLM
    def query_llm_for_solution(self, agent_name, error_message):
        self.get_logger().info(f"Querying LLM for {agent_name}'s error: {error_message}")

        response = openai.ChatCompletion.create(
            model="gpt-3.5-turbo",
            messages=[
                {"role": "system", "content": self.system_prompt},
                {"role": "user", "content": f"{agent_name} encountered the following error: {error_message}. Please suggest a solution or warn if none can be found."}
            ]
        )

        llm_response = response['choices'][0]['message']['content']
        self.get_logger().info(f"LLM Response: {llm_response}")
        return llm_response

    # Function to publish commands
    def publish_command(self, command):
        msg = String()
        msg.data = command
        self.command_pub.publish(msg)
        self.get_logger().info(f"Sent command: {msg.data}")

    # Stability Agent Callback
    def stability_callback(self, msg):
        self.get_logger().info(f"Stability Agent Status: {msg.data}")
        if "done" in msg.data:
            self.publish_command("Start planning the next step")
        elif "error" in msg.data:
            solution = self.query_llm_for_solution("Stability Agent", msg.data)
            if "no solution" in solution.lower():
                self.get_logger().warning("No solution found by LLM for Stability Agent.")
            else:
                self.publish_command(solution)

    # Planning Agent Callback
    def planning_callback(self, msg):
        self.get_logger().info(f"Planning Agent Status: {msg.data}")
        if "done" in msg.data:
            self.publish_command("Check with Expert Knowledge")
        elif "error" in msg.data:
            solution = self.query_llm_for_solution("Planning Agent", msg.data)
            if "no solution" in solution.lower():
                self.get_logger().warning("No solution found by LLM for Planning Agent.")
            else:
                self.publish_command(solution)

    # Expert Knowledge Agent Callback
    def expert_callback(self, msg):
        self.get_logger().info(f"Expert Agent Status: {msg.data}")
        if "done" in msg.data:
            self.publish_command("Human-Robot Communication check")
        elif "error" in msg.data:
            solution = self.query_llm_for_solution("Expert Knowledge Agent", msg.data)
            if "no solution" in solution.lower():
                self.get_logger().warning("No solution found by LLM for Expert Knowledge Agent.")
            else:
                self.publish_command(solution)

    # Human-Robot Communicator Callback
    def human_robot_callback(self, msg):
        self.get_logger().info(f"Human-Robot Communicator Status: {msg.data}")
        if "done" in msg.data:
            self.get_logger().info("All tasks completed successfully!")
        elif "error" in msg.data:
            solution = self.query_llm_for_solution("Human-Robot Communicator", msg.data)
            if "no solution" in solution.lower():
                self.get_logger().warning("No solution found by LLM for Human-Robot Communicator.")
            else:
                self.publish_command(solution)

def main(args=None):
    rclpy.init(args=args)
    manager_agent = ManagerAgent()
    rclpy.spin(manager_agent)
    manager_agent.destroy_node()
    rclpy.shutdown()

if __name__ == "__main__":
    main()

