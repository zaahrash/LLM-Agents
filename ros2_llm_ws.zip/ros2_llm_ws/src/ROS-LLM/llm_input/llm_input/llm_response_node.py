#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import openai
import rclpy
from rclpy.node import Node
from std_msgs.msg import String

# Set your OpenAI API key
openai.api_key = "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"

class LLMResponseNode(Node):
    def __init__(self):
        super().__init__("llm_response_node")
        self.subscription = self.create_subscription(String, "/llm_input_audio_to_text", self.listener_callback, 0)
        self.publisher = self.create_publisher(String, "/llm_response", 0)

    def listener_callback(self, msg):
        user_input = msg.data
        self.get_logger().info(f"Received input: {user_input}")

        # Using the new API format
        response = openai.ChatCompletion.create(
            model="gpt-3.5-turbo",
            messages=[
                {"role": "system", "content": "You are a helpful assistant."},
                {"role": "user", "content": user_input},
            ]
        )

        llm_response = response['choices'][0]['message']['content']
        self.get_logger().info(f"Generated response: {llm_response}")

        # Publish the response to the /llm_response topic
        response_msg = String()
        response_msg.data = llm_response
        self.publisher.publish(response_msg)
        self.get_logger().info("Response published.")

def main(args=None):
    rclpy.init(args=args)
    node = LLMResponseNode()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()

if __name__ == "__main__":
    main()

