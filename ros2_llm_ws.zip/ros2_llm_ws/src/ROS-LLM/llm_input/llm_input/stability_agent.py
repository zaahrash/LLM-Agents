#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
from std_msgs.msg import String
import json

class StabilityAgent(Node):
    def __init__(self):
        super().__init__("stability_agent")

        # Extended System Prompt for Stability Agent
        self.system_prompt = """
        You are the Stability Analysis Agent. You will receive physics simulation data from Unity.
        Your job is to assess the stability of the structure during the disassembly process using the simulation data.
        If any stability issue arises, you will send an error message to the Manager Agent and suggest corrective actions.
        If the structure is stable, you will confirm the stability to the Manager Agent and move on to the next step.
        """
        self.get_logger().info(f"System Prompt: {self.system_prompt}")

        # Publisher to publish the stability evaluation
        self.stability_publisher = self.create_publisher(String, "/stability_status", 10)

        # Read the JSON file with simulation data
        self.read_and_process_simulation_data()

    def read_and_process_simulation_data(self):
        try:
            # Reading JSON file
            with open('/path/to/simulationData.json', 'r') as f:
                data = json.load(f)
            
            # Process stability data
            stability_value = data['stabilityValue']
            is_stable = data['isStable']

            # Log the received data
            self.get_logger().info(f"Received stability value: {stability_value}, Is Stable: {is_stable}")

            # Publishing stability result based on the evaluation
            msg = String()
            if not is_stable:
                msg.data = f"Error: Structure is unstable. Suggested corrective action: Recheck stability parameters."
                self.get_logger().error(f"Unstable structure detected. Suggested action: {msg.data}")
            else:
                msg.data = "Stability evaluation completed: Structure is stable."
                self.get_logger().info(f"Stability confirmed. Proceeding to next step.")

            self.stability_publisher.publish(msg)

        except Exception as e:
            self.get_logger().error(f"Error reading or processing the JSON file: {e}")

def main(args=None):
    rclpy.init(args=args)
    stability_agent = StabilityAgent()
    rclpy.spin(stability_agent)
    stability_agent.destroy_node()
    rclpy.shutdown()

if __name__ == "__main__":
    main()

