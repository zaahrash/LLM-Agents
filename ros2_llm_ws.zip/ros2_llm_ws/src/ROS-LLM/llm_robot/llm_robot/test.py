pose=[1,3,4,4.4]
print(pose)
print(type(pose))
pose =str(pose)
print(type(pose))
