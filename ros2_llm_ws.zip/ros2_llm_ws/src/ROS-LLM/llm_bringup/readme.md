# llm_bringup
## Package Description
This package is used to launch the related nodes for the ROS-LLM project. This will run within the Robot Operating System 2 (ROS2) framework.

# chatgpt_with_robot_test.launch.py
