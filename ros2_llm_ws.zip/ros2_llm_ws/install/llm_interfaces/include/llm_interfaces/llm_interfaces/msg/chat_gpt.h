// generated from rosidl_generator_c/resource/idl.h.em
// with input from llm_interfaces:msg/ChatGPT.idl
// generated code does not contain a copyright notice

#ifndef LLM_INTERFACES__MSG__CHAT_GPT_H_
#define LLM_INTERFACES__MSG__CHAT_GPT_H_

#include "llm_interfaces/msg/detail/chat_gpt__struct.h"
#include "llm_interfaces/msg/detail/chat_gpt__functions.h"
#include "llm_interfaces/msg/detail/chat_gpt__type_support.h"

#endif  // LLM_INTERFACES__MSG__CHAT_GPT_H_
